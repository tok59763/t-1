<?php
$id_telegram = "62255";
$id_botTele  = "6466859393:AAHHDkU0ZGeUpl4W";
?>
